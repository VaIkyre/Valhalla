﻿using UnityEngine;
using System.Collections;

public class move : MonoBehaviour
{
    public Color c1 = Color.yellow;
    public Color c2 = Color.red;
    public GameObject ObjectA;
    public GameObject ObjectB;
    public TextMesh ObjectC;


    void Start()
    {
        LineRenderer lineRenderer = gameObject.AddComponent<LineRenderer>();
        lineRenderer.material = new Material(Shader.Find("Particles/Additive"));
        lineRenderer.SetColors(c1, c2);
        lineRenderer.SetWidth(0.1f, 0.1f);


    }

    void Update()
    {
        LineRenderer lineRenderer = GetComponent<LineRenderer>();
        Vector3 X;
        Vector3 Y;
        Vector3 Z;
        X = ObjectA.transform.position;
        Y = ObjectB.transform.position;
        Z = ObjectC.transform.position;

        float dist = Vector3.Distance(X, Y);
        ObjectC.transform.position = new Vector3((X.x + Y.x) / 2, (X.y + Y.y) / 2, (X.z + Y.z) / 2);
        lineRenderer.SetPosition(0, X);
        lineRenderer.SetPosition(1, Y);

        ObjectC.text = dist + "m";

    }
}